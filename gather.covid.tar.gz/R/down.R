
# Criacao de arquivo de dados otimizado para o dashboard


# função que lê diretamente o gzip do servidor do brasil.io e retorna o respectivo csv
downCorona <- function(file_url) {
  con <- gzcon(url(file_url))
  txt <- readLines(con)
  return(read.csv(textConnection(txt)))
}

# funcao que pega o arquivo de casos do brasil.io, faz um pequeno tratamento e retorna-o
# retornos permitidos:
# caso_full: retorna a contagem de casos de todos os municipios desde o dia 0
# cart: obitos em cartório
# last_cases: ultimo balanço divulgado, com latitude e longitude
pegaCorona <- function(tipo = "caso_full", baixar = TRUE){

  if(baixar){
    print("Fazendo o download....")
    dados <- downCorona("https://data.brasil.io/dataset/covid19/caso_full.csv.gz")
    cart <- downCorona("https://data.brasil.io/dataset/covid19/obito_cartorio.csv.gz")
  }
  # caso já tenha o arquivo na pasta
  else
    dados<-read.csv(file = "caso_full.csv",header=TRUE)

  print("Download concluido. Transformando os dados")
  dados$tempo<- as.numeric(as.Date(dados$date) - min(as.Date(dados$date)))
  dados$date <- as.Date(dados$date)

  if(tipo == "cart")
    return(cart)
  else if(tipo == "caso_full")
    return (dados)

  else
  # acrescentando latitude e longitude nos ultimos casos

  latlong_cidade<-system.file("extdata", 'latitude-longitude-cidades.csv', package = "gather.covid", mustWork =  T)
  latlong_cidade$city <-latlong_cidade$municipio
  latlong_cidade$state <-latlong_cidade$uf

  latlong_estado<-system.file("extdata", 'latitude-longitude-estados.csv', package = "gather.covid", mustWork =  T)
  latlong_estado$state <-latlong_estado$uf
  latlong_estado$place_type='state'

  dados <- dados %>% filter(is_last == "True")

  dados2 <- merge(dados,latlong_cidade,by=c('state','city'), all.x=TRUE, all.y=FALSE)
  dados <- merge(dados2,latlong_estado,by=c('state','place_type'), all.x=TRUE, all.y=FALSE)

  dados <-dados %>%
    tidyverse::mutate(latitude = ifelse(place_type=='city', latitude.x, latitude.y),
           longitude = ifelse(place_type=='city',longitude.x, longitude.y))

  dados <-tidyverse::select(dados, -c('uf.x','uf.y','latitude.x','longitude.x','latitude.y','longitude.y'))

  dados <- dados %>% tidyverse::drop_na(latitude,longitude)

  return(dados)

}
